// api/enviar-resultado.js
// Função serverless da Vercel: gera relatório via Claude API e envia por email via SendGrid

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Método não permitido' });
  }

  const { nome, email, iq, nivel, correct, total } = req.body;

  if (!nome || !email || !iq) {
    return res.status(400).json({ error: 'Dados incompletos' });
  }

  // ── 1. Gerar relatório personalizado com Claude ──────────────────────────────
  let relatorio = '';
  try {
    const claudeRes = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1200,
        messages: [{
          role: 'user',
          content: `Você é um especialista em psicometria. Gere um relatório de QI em HTML (apenas o corpo interno, sem <html>/<head>/<body>) para envio por e-mail via SendGrid.

Dados:
- Nome: ${nome}
- Acertos: ${correct} de ${total}
- QI Estimado: ${iq}
- Nível: ${nivel}

Use estas tags HTML inline simples compatíveis com email:
<h2> para títulos, <p> para parágrafos, <strong> para destaques, <ul><li> para listas.
NÃO use CSS externo nem classes — apenas style inline simples quando necessário.

Estrutura do relatório:
1. Saudação personalizada com o nome
2. Resultado em destaque: QI ${iq} — Nível ${nivel}
3. O que significa esse resultado (contexto na população)
4. Análise por categorias (Raciocínio Lógico, Matemática, Verbal, Espacial, Padrões)
5. Pontos fortes identificados
6. 3 dicas práticas para desenvolvimento cognitivo
7. Fechamento motivacional

Seja caloroso, profissional e detalhado (400–600 palavras).`
        }]
      })
    });

    const claudeData = await claudeRes.json();
    relatorio = claudeData.content?.[0]?.text || '<p>Relatório gerado com sucesso.</p>';
  } catch (err) {
    console.error('Erro na Claude API:', err);
    relatorio = `<p>Olá, <strong>${nome}</strong>! Seu QI estimado é <strong>${iq}</strong> — nível <strong>${nivel}</strong>.</p><p>Acertos: ${correct} de ${total} questões.</p>`;
  }

  // ── 2. Montar o HTML do email ────────────────────────────────────────────────
  const emailHtml = `
<!DOCTYPE html>
<html lang="pt-BR">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>Seu Resultado de QI</title></head>
<body style="margin:0;padding:0;background:#0F0F0F;font-family:'DM Sans',Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#0F0F0F;padding:40px 20px;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">

        <!-- Header -->
        <tr><td style="background:#1A1A1A;border:1px solid rgba(201,168,76,0.3);border-radius:4px 4px 0 0;padding:40px;text-align:center;">
          <div style="width:80px;height:80px;border-radius:50%;border:2px solid #C9A84C;margin:0 auto 20px;display:flex;align-items:center;justify-content:center;font-family:Georgia,serif;font-size:28px;font-weight:900;color:#C9A84C;line-height:80px;">QI</div>
          <p style="color:#C9A84C;font-size:11px;letter-spacing:0.25em;text-transform:uppercase;margin:0 0 8px;">Avaliação Cognitiva Oficial</p>
          <h1 style="color:#F0EDE6;font-family:Georgia,serif;font-size:32px;font-weight:900;margin:0;">Seu Resultado</h1>
        </td></tr>

        <!-- Score -->
        <tr><td style="background:#C9A84C;padding:30px;text-align:center;">
          <p style="color:#0F0F0F;font-size:12px;text-transform:uppercase;letter-spacing:0.2em;margin:0 0 8px;font-weight:500;">QI ESTIMADO</p>
          <div style="font-family:Georgia,serif;font-size:72px;font-weight:900;color:#0F0F0F;line-height:1;">${iq}</div>
          <div style="font-size:20px;font-weight:500;color:#0F0F0F;margin-top:8px;">${nivel}</div>
          <p style="color:rgba(0,0,0,0.6);font-size:13px;margin:12px 0 0;">${correct} de ${total} questões corretas</p>
        </td></tr>

        <!-- Body -->
        <tr><td style="background:#1A1A1A;border:1px solid rgba(201,168,76,0.3);border-top:none;padding:40px;color:#F0EDE6;font-size:15px;line-height:1.7;">
          ${relatorio}
        </td></tr>

        <!-- Footer -->
        <tr><td style="background:#0F0F0F;padding:30px;text-align:center;border-top:1px solid rgba(201,168,76,0.2);">
          <p style="color:#8A8480;font-size:12px;margin:0;">Este relatório foi gerado exclusivamente para <strong style="color:#C9A84C;">${nome}</strong></p>
          <p style="color:#8A8480;font-size:11px;margin:8px 0 0;">Teste de QI Oficial · Resultado confidencial</p>
        </td></tr>

      </table>
    </td></tr>
  </table>
</body>
</html>`;

  // ── 3. Enviar email via SendGrid ─────────────────────────────────────────────
  try {
    const sgRes = await fetch('https://api.sendgrid.com/v3/mail/send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.SENDGRID_API_KEY}`,
      },
      body: JSON.stringify({
        personalizations: [{ to: [{ email, name: nome }] }],
        from: {
          email: process.env.EMAIL_REMETENTE,   // ex: resultado@seudominio.com
          name: 'Teste de QI Oficial'
        },
        subject: `${nome}, seu QI é ${iq} — veja sua análise completa`,
        content: [{ type: 'text/html', value: emailHtml }],
      })
    });

    if (!sgRes.ok) {
      const errBody = await sgRes.text();
      console.error('Erro SendGrid:', errBody);
      return res.status(500).json({ error: 'Falha ao enviar o e-mail.' });
    }

    return res.status(200).json({ success: true, message: 'E-mail enviado com sucesso!' });

  } catch (err) {
    console.error('Erro ao enviar email:', err);
    return res.status(500).json({ error: 'Erro interno ao enviar e-mail.' });
  }
}
